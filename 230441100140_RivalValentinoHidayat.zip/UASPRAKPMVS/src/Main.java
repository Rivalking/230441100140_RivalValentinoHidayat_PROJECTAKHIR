/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author rival
 */
public class Main {
   public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                // Periksa apakah user sudah login
                if (Session.isLoggedIn) {
                    // Jika sudah login, tampilkan PanelUtama dengan username yang valid
                    new PanelUtama(Session.currentUser).setVisible(true);
                } else {
                    // Jika belum login, arahkan ke login form
                    new Panellogin().setVisible(true);
                }
            }
        });
    }
}
